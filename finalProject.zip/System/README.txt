Affidavit:
I attest that I am the sole author of this submitted work and any code borrowed
from other sources has been identified by comments placed in my submitted code.
Raushan Mohamed, 101305556

Install Command:
To install npm modules execute:
npm install

This will install the modules listed as dependencies in the package.json file.

Launch Command:
To run either execute
node server.js

Test Instructions: 
http://localhost:3000

youtube link: https://youtu.be/OzHwnA9xlqo
