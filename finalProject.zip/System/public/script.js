document.addEventListener("DOMContentLoaded", function() {
  let user_id;
  let goal;
  let loginButton = document.getElementById("login-button");
  let signupButton = document.getElementById("signup-button");
  let submitButton = document.getElementById("submit-button");
  let loginScreen = document.getElementById("login-screen");
  let signupScreen = document.getElementById("signup-screen");
  let mainScreen = document.getElementById("mainScreen");
  let errorMessage = document.getElementById("error-message");
  let adminScreen = document.getElementById("adminScreen");
  let playerList = document.getElementById("PlayerList");
  let playerName = document.getElementById("player-username");
  let playerLevel = document.getElementById("player-level");
  let playerXP = document.getElementById("player-xp");
  let playerXPR = document.getElementById("player-xpr");
  let playerStrength = document.getElementById("player-strength");
  let playerIntelligence = document.getElementById("player-intelligence");
  let playerVitality = document.getElementById("player-vitality");
  let playerStatusWindow = document.getElementById("playerStatus");
  let generateQuestButton = document.getElementById("generate-quest");

  signupButton.addEventListener("click", function() {
    loginScreen.style.display = "none";
    signupScreen.style.display = "block";
  });

  function drawPlayerStatus(playerId) {
    fetch(`/getPlayerStatus`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ playerId }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          //playerStatusWindow.innerHTML = '';

          playerName.innerHTML = "";
          playerLevel.innerHTML = "";
          playerXP.innerHTML = "";
          playerXPR.innerHTML = "";
          playerStrength.innerHTML = "";
          playerIntelligence.innerHTML = "";
          playerVitality.innerHTML = "";

          playerName.innerHTML = data.player_data.username;
          playerLevel.innerHTML = data.player_data.level;
          playerXP.innerHTML = data.player_data.xp;
          playerXPR.innerHTML = data.player_data.xpr;
          playerStrength.innerHTML = data.player_data.strength;
          playerIntelligence.innerHTML = data.player_data.intelligence;
          playerVitality.innerHTML = data.player_data.vitality;
        }
      })
      .catch((error) => {
        console.error("Error fetching player stats:", error);
      });
  }

  function loadActiveQuests(playerId) {
    let questList = document.getElementById("active-quests");
    questList.innerHTML = "";
    //drawPlayerStatus(playerId);
    while (questList.firstChild) {
      questList.removeChild(questList.firstChild);
    }

    fetch(`/activeQuests`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ playerId }),
    })
      .then((res) => res.json())
      .then((quests) => {
        quests.quests.forEach((quest) => {
          let questDiv = document.createElement("div");
          questDiv.classList.add("quest");

          let title = document.createElement("p");
          title.textContent = "task: " + quest.title;
          questDiv.appendChild(title);

          let description = document.createElement("p");
          description.textContent = "description: " + quest.description;
          questDiv.appendChild(description);

          let xp = document.createElement("p");
          xp.textContent = `XP: +${quest.xp}`;
          questDiv.appendChild(xp);

          let duration = document.createElement("p");

          let current_time_seconds = Math.floor(Date.now() / 1000);
          let elapsed_time = current_time_seconds - quest.start_time;
          let current_duration = quest.duration - elapsed_time;

          let hours = Math.floor(current_duration/ 3600);
          let minutes = Math.floor((current_duration % 3600) / 60);
          let seconds = current_duration % 60;   
          duration.textContent = `Duration: ${hours}h ${minutes}m ${seconds}s`;
          questDiv.appendChild(duration);

          let completeButton = document.createElement("button");
          completeButton.textContent = "Completed";
          completeButton.classList.add("complete-btn");
          completeButton.onclick = () =>
            updateQuestStatus(quest.quest_id, playerId, "completed");

          questDiv.appendChild(completeButton);
          questList.appendChild(questDiv);
        });
      })
      .catch((error) => {
        console.error("Error loading quests:", error);
      });
  }

  function updateQuestStatus(questId, playerId, status) {
    fetch(`/updateQuestStatus`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questId, playerId, status }),
    })
      .then((response) => response.json())
      .then(() => {
        loadActiveQuests(playerId);
        drawPlayerStatus(playerId);
      })

      .catch((error) => {
        console.error("Error updating quest status:", error);
      });
  }

  generateQuestButton.addEventListener("click", () => {
    fetch("/generateQuest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        player_Id: user_id,
        goal: goal,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          console.log("New Quest:", data.quest);
          loadActiveQuests(user_id);
        }
      })
      .catch((err) => console.error("Error generating quest:", err));
  });

  loginButton.addEventListener("click", function() {
    errorMessage.textContent = " ";
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    if (!username || username == "Username") {
      errorMessage.textContent = "Error please enter a username";
      return;
    }
    if (!password) {
      errorMessage.textContent = "Error please enter a password";
      return;
    }

    fetch("/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success == true) {
          loginScreen.style.display = "none";

          if (data.is_admin) {
            adminScreen.style.display = "block";

            let html = "<table><tr><th>Players</th></tr>";

            data.users.forEach((user) => {
              html += `
            <tr>
              <td>${user.username}</td>
            </tr>
          `;
            });

            html += "</table>";

            playerList.innerHTML = html;
          } else {
            mainScreen.style.display = "block";

            playerName.innerHTML = data.player_data.username;
            playerLevel.innerHTML = data.player_data.level;
            playerXP.innerHTML = data.player_data.xp;
            playerXPR.innerHTML = data.player_data.xpr;
            playerStrength.innerHTML = data.player_data.strength;
            playerIntelligence.innerHTML = data.player_data.intelligence;
            playerVitality.innerHTML = data.player_data.vitality;
            user_id = data.player_data.id;
            goal = data.player_data.goal;
            loadActiveQuests(data.player_data.id);
          }
        } else {
          errorMessage.textContent = data.message;
        }
      });
  });

  submitButton.addEventListener("click", function() {
    errorMessage.textContent = " ";
    console.log("sumbit clicked");

    let username = document.getElementById("signup-username").value;
    let password = document.getElementById("signup-password").value;
    let goal = document.getElementById("goal-bar").value;

    console.log(username);

    if (!username) {
      errorMessage.textContent = "Error please enter a username.";
      return;
    }
    if (!password) {
      errorMessage.textContent = "Error please enter a password.";
      return;
    }
    if (!goal) {
      errorMessage.textContent = "Please fill out a goal";
      return;
    }

    fetch("/signup", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password, goal }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          signupScreen.style.display = "none";
          loginScreen.style.display = "block";
        } else {
          errorMessage.textContent = data.message;
        }
      })
      .catch((error) => {
        errorMessage.textContent = "An error occurred.";
      });
  });
});
