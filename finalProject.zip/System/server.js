var http = require("http");
var express = require("express");
var path = require("path");
var logger = require("morgan");
var sqlite3 = require("sqlite3").verbose();
let db = new sqlite3.Database("./data/PlayerBase.db");
var app = express();

const OpenAI = require("openai");

const openai = new OpenAI({
  apiKey:
    "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",
});

const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs");
app.locals.pretty = true;

app.get("/", (req, res) => {
  res.render("index.hbs");
});

app.post("/generateQuest", (req, res) => {
  let { player_Id, goal } = req.body;
  const completion = openai.chat.completions.create({
    model: "gpt-4o-mini",
    store: true,
    messages: [
      {
        role: "user",
        content:
          "give me a quest pertaining to this goal: " + goal +  " in the form of {'title': ,'xp': }  say absolutly nothing else and replace the single quotes with double quotes.",
      },
    ],
  });

  completion.then((result) => {
    console.log(result.choices[0].message.content);

    let data = JSON.parse(result.choices[0].message.content);

    console.log(data.title);
    let newQuest = {
      title: data.title,
      description: "not available",
      xp: data.xp,
      reward: "not available",
      punishment: "not available",
      start_time: Math.floor(Date.now() / 1000), // current Unix timestamp in seconds
      duration: 259200, // this is like 3 days in seconds
      player_id: player_Id,
      status: "active",
    };

    db.run(
      `INSERT INTO quests 
   (title, description, xp, reward, punishment, start_time, duration, player_id, status)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newQuest.title,
        newQuest.description,
        newQuest.xp,
        newQuest.reward,
        newQuest.punishment,
        newQuest.start_time,
        newQuest.duration,
        newQuest.player_id,
        newQuest.status,
      ],
      function(err) {
        if (err) {
          return res.send({ success: false, error: err.message });
        }

        return res.send({ success: true, quest: newQuest });
      },
    );

    //let object = JSON.parse(result.content);
    // console.log(object.title);
  });

  // let data = { title: "create a keylogger", xp: 20 };
  // console.log("this is the " + player_Id);

  // let newQuest = {
  //   title: data.title,
  //   description: "not available",
  //   xp: data.xp,
  //   reward: "not available",
  //   punishment: "not available",
  //   start_time: Math.floor(Date.now() / 1000), // current Unix timestamp in seconds
  //   duration: 259200, // this is like 3 days in seconds
  //   player_id: player_Id,
  //   status: "active",
  // };
  //
  // db.run(
  //   `INSERT INTO quests 
  //  (title, description, xp, reward, punishment, start_time, duration, player_id, status)
  //  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  //   [
  //     newQuest.title,
  //     newQuest.description,
  //     newQuest.xp,
  //     newQuest.reward,
  //     newQuest.punishment,
  //     newQuest.start_time,
  //     newQuest.duration,
  //     newQuest.player_id,
  //     newQuest.status,
  //   ],
  //   function(err) {
  //     if (err) {
  //       return res.send({ success: false, error: err.message });
  //     }
  //
  //     return res.send({ success: true, quest: newQuest });
  //   },
  // );
});

app.post("/login", (req, res) => {
  let is_admin = false;
  let { username, password } = req.body;

  db.get("SELECT * FROM users WHERE username = ?", [username], (err, data) => {
    if (err) {
      console.log("error when quering database");
      res.send({ success: false });
    }
    if (data) {
      if (data.username === username && data.password === password) {
        if (data.status == "admin") {
          db.all("SELECT * FROM users", (err, users) => {
            is_admin = true;
            return res.send({
              success: true,
              is_admin: is_admin,
              users: users,
            });
          });
        } else {
          is_admin = false;
          return res.send({
            success: true,
            is_admin: false,
            player_data: data,
          });
        }
      }
      if (data.username === username && data.password != password) {
        return res.send({
          success: false,
          message: "ERROR: incorrect password",
        });
      }
    } else {
      return res.send({ success: false, message: "ERROR: unauthorized user" });
    }
  });
});

app.post("/activeQuests", (req, res) => {
  let { playerId } = req.body;
  db.all(
    "SELECT * FROM quests WHERE player_id = ? AND status = 'active'",
    [playerId],
    (err, rows) => {
      if (err) {
        console.error("Error fetching active quests:", err);
        return res.send({
          success: false,
          message: "Failed to load active quests",
        });
      }
      if (rows.length > 0) {
        return res.send({ quests: rows });
      }
      return res.send({ quests: [] });
    },
  );
});

function updatePlayer(playerId, xp) {
  db.get(
    "SELECT xp, level FROM users WHERE id = ?",
    [playerId],
    (err, user) => {
      if (err || !user) {
        console.log("Error fetching player stats:", err);
        return { success: false, message: "Failed to fetch player stats" };
      }

      let newXp = user.xp + xp;
      let newLevel = user.level + Math.floor(newXp / 100);
      let remainingXp = newXp % 100;

      db.run(
        "UPDATE users SET xp = ?, level = ? WHERE id = ?",
        [remainingXp, newLevel, playerId],
        (err) => {
          if (err) {
            console.error("Error updating player stats:", err);
            return;
          }
        },
      );
    },
  );
}

app.post("/updateQuestStatus", (req, res) => {
  let { questId, playerId, status } = req.body;

  db.run(
    "UPDATE quests SET status = ? WHERE quest_id = ? AND player_id = ?",
    [status, questId, playerId],
    function(err) {
      if (err) {
        console.error("Error updating quest status:", err);
        return res.send({
          success: false,
          message: "Failed to update quest status",
        });
      }
      if (status === "completed") {
        db.get(
          "SELECT xp FROM quests WHERE quest_id = ? AND player_id = ?",
          [questId, playerId],
          (err, quest) => {
            if (err || !quest) {
              console.log("Error fetching quest XP:", err);
            }

            updatePlayer(playerId, quest.xp);
          },
        );
      }
      return res.send({ success: true, message: `Quest ${status}` });
    },
  );
});

app.post("/getPlayerStatus", (req, res) => {
  let { playerId } = req.body;

  db.get("SELECT * FROM users WHERE id = ?", [playerId], (err, data) => {
    if (err) {
      console.log("error when quering database");
      return res.send({ success: false });
    }
    if (data) {
      return res.send({ success: true, player_data: data });
    }
  });
});

app.post("/signup", (req, res) => {
  let { username, password, goal } = req.body;

  db.get("SELECT * FROM users WHERE username = ?", [username], (err, data) => {
    if (err) {
      console.log("error when quering database");
      res.send({ success: false, message: "ERROR when signing up" });
    }
    if (data) {
      res.send({ success: false, message: "ERROR username is already taken" });
    }
  });

  let stmt = db.prepare(
    "INSERT INTO users (username, password, goal) VALUES (?, ?, ?)",
  );
  stmt.run(username, password, goal, () => {
    return res.json({ success: true });
  });
});

app.listen(PORT, (err) => {
  if (err) console.log(err);
  else {
    console.log(`Player System running on port: ${PORT} `);
    console.log("http://localhost:3000");
  }
});
